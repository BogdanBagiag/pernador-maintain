export default function Reports() {
  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Reports</h1>
      <div className="card">
        <p className="text-gray-600">Reports and analytics will be here</p>
      </div>
    </div>
  )
}
