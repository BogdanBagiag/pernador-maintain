import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface EmailRequest {
  type: 'wo_assigned' | 'wo_urgent' | 'wo_overdue' | 'wo_completed' | 'schedule_due' | 'schedule_overdue'
  work_order_id?: string
  schedule_id?: string
  user_id: string
}

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Initialize Supabase client with SERVICE ROLE for internal operations
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    // Get Resend API key
    const resendApiKey = Deno.env.get('RESEND_API_KEY')
    if (!resendApiKey) {
      throw new Error('RESEND_API_KEY is not configured')
    }

    // Parse request body
    const body: EmailRequest = await req.json()
    const { type, work_order_id, schedule_id, user_id } = body

    console.log('Email notification request:', { type, work_order_id, schedule_id, user_id })

    // Get user profile and check preferences
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('email, full_name')
      .eq('id', user_id)
      .single()

    if (profileError || !profile || !profile.email) {
      console.error('User not found or no email:', profileError)
      return new Response(
        JSON.stringify({ error: 'User not found or no email address' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Check notification preferences (if table exists)
    const { data: preferences } = await supabase
      .from('notification_preferences')
      .select('email_enabled, notify_wo_assigned, notify_wo_urgent, notify_wo_completed')
      .eq('user_id', user_id)
      .single()

    // If preferences exist and emails are disabled, skip
    if (preferences && !preferences.email_enabled) {
      console.log('Email notifications disabled for user:', user_id)
      return new Response(
        JSON.stringify({ success: true, message: 'Email notifications disabled for user' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Fetch work order or schedule data
    let emailSubject = ''
    let emailBody = ''
    let workOrderData: any = null

    if (work_order_id) {
      const { data: wo, error: woError } = await supabase
        .from('work_orders')
        .select(`
          id,
          title,
          description,
          priority,
          status,
          scheduled_date,
          equipment:equipment_id (
            name,
            serial_number
          )
        `)
        .eq('id', work_order_id)
        .single()

      if (woError || !wo) {
        console.error('Work order not found:', woError)
        throw new Error('Work order not found')
      }

      workOrderData = wo
    }

    // Generate email content based on type
    const appUrl = Deno.env.get('APP_URL') || 'https://mentenanta.pernador.ro'
    
    switch (type) {
      case 'wo_assigned':
        emailSubject = '🔧 Comandă Nouă Asignată'
        emailBody = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background: #1e40af; color: white; padding: 20px; text-align: center;">
              <h1 style="margin: 0;">🔧 Pernador Maintenance</h1>
            </div>
            <div style="padding: 30px; background: #f9fafb;">
              <h2 style="color: #1e40af;">Comandă Nouă Asignată</h2>
              <p>Bună ${profile.full_name},</p>
              <p>Ți-a fost asignată o comandă de lucru nouă:</p>
              <div style="background: white; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <h3 style="margin-top: 0; color: #111827;">${workOrderData.title}</h3>
                ${workOrderData.equipment ? `<p><strong>Echipament:</strong> ${workOrderData.equipment.name}</p>` : ''}
                <p><strong>Prioritate:</strong> <span style="padding: 4px 8px; border-radius: 4px; background: ${
                  workOrderData.priority === 'critical' ? '#dc2626' :
                  workOrderData.priority === 'high' ? '#f59e0b' :
                  workOrderData.priority === 'medium' ? '#3b82f6' : '#6b7280'
                }; color: white;">${workOrderData.priority.toUpperCase()}</span></p>
                ${workOrderData.scheduled_date ? `<p><strong>Termen:</strong> ${new Date(workOrderData.scheduled_date).toLocaleDateString('ro-RO')}</p>` : ''}
                ${workOrderData.description ? `<p style="color: #6b7280;">${workOrderData.description}</p>` : ''}
              </div>
              <div style="text-align: center; margin: 30px 0;">
                <a href="${appUrl}/work-orders/${work_order_id}" 
                   style="background: #1e40af; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
                  Vezi Detalii →
                </a>
              </div>
            </div>
            <div style="background: #e5e7eb; padding: 20px; text-align: center; color: #6b7280; font-size: 14px;">
              <p>© 2026 Pernador Maintenance System</p>
            </div>
          </div>
        `
        break

      case 'wo_urgent':
        emailSubject = '🚨 Comandă URGENTĂ!'
        emailBody = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background: #dc2626; color: white; padding: 20px; text-align: center;">
              <h1 style="margin: 0;">🚨 URGENT - Pernador Maintenance</h1>
            </div>
            <div style="padding: 30px; background: #fef2f2;">
              <h2 style="color: #dc2626;">Comandă cu Prioritate Înaltă!</h2>
              <p>Bună ${profile.full_name},</p>
              <p><strong>O comandă de lucru a fost marcată ca URGENTĂ și necesită atenție imediată!</strong></p>
              <div style="background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #dc2626;">
                <h3 style="margin-top: 0; color: #dc2626;">${workOrderData.title}</h3>
                ${workOrderData.equipment ? `<p><strong>Echipament:</strong> ${workOrderData.equipment.name}</p>` : ''}
                <p><strong>Prioritate:</strong> <span style="padding: 4px 8px; border-radius: 4px; background: #dc2626; color: white;">CRITICAL/HIGH</span></p>
                ${workOrderData.description ? `<p style="color: #6b7280;">${workOrderData.description}</p>` : ''}
              </div>
              <div style="text-align: center; margin: 30px 0;">
                <a href="${appUrl}/work-orders/${work_order_id}" 
                   style="background: #dc2626; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
                  Vezi Comanda URGENT →
                </a>
              </div>
            </div>
            <div style="background: #e5e7eb; padding: 20px; text-align: center; color: #6b7280; font-size: 14px;">
              <p>© 2026 Pernador Maintenance System</p>
            </div>
          </div>
        `
        break

      case 'wo_completed':
        emailSubject = '✅ Comandă Finalizată'
        emailBody = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background: #059669; color: white; padding: 20px; text-align: center;">
              <h1 style="margin: 0;">✅ Pernador Maintenance</h1>
            </div>
            <div style="padding: 30px; background: #f0fdf4;">
              <h2 style="color: #059669;">Comandă Finalizată</h2>
              <p>Bună ${profile.full_name},</p>
              <p>Comanda de lucru a fost finalizată:</p>
              <div style="background: white; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <h3 style="margin-top: 0; color: #111827;">${workOrderData.title}</h3>
                ${workOrderData.equipment ? `<p><strong>Echipament:</strong> ${workOrderData.equipment.name}</p>` : ''}
                <p><strong>Status:</strong> <span style="padding: 4px 8px; border-radius: 4px; background: #059669; color: white;">COMPLETED</span></p>
              </div>
              <div style="text-align: center; margin: 30px 0;">
                <a href="${appUrl}/work-orders/${work_order_id}" 
                   style="background: #059669; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
                  Vezi Detalii →
                </a>
              </div>
            </div>
            <div style="background: #e5e7eb; padding: 20px; text-align: center; color: #6b7280; font-size: 14px;">
              <p>© 2026 Pernador Maintenance System</p>
            </div>
          </div>
        `
        break

      default:
        throw new Error(`Unknown notification type: ${type}`)
    }

    // Send email via Resend
    const resendResponse = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${resendApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: 'Pernador Maintenance <noreply@resend.dev>',
        to: [profile.email],
        subject: emailSubject,
        html: emailBody,
      }),
    })

    const resendData = await resendResponse.json()

    if (!resendResponse.ok) {
      console.error('Resend API error:', resendData)
      
      // Log to email_logs with error
      await supabase.from('email_logs').insert({
        to_email: profile.email,
        from_email: 'noreply@resend.dev',
        subject: emailSubject,
        template_type: type,
        work_order_id,
        schedule_id,
        user_id,
        status: 'failed',
        error_message: JSON.stringify(resendData),
      })

      throw new Error(`Resend API error: ${JSON.stringify(resendData)}`)
    }

    // Log successful send
    await supabase.from('email_logs').insert({
      to_email: profile.email,
      from_email: 'noreply@resend.dev',
      subject: emailSubject,
      template_type: type,
      work_order_id,
      schedule_id,
      user_id,
      status: 'sent',
      sent_at: new Date().toISOString(),
      resend_id: resendData.id,
    })

    console.log('Email sent successfully:', resendData.id)

    return new Response(
      JSON.stringify({ success: true, email_id: resendData.id }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Error sending email:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
