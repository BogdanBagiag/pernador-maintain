# Fix Edge Function - Remove Auth Requirement

## 🎯 Problema:
Edge function returnează 401 când e apelat de trigger, pentru că trigger-ul nu trimite authentication headers.

## ✅ Soluția:
Edge function folosește **SERVICE_ROLE_KEY** (care e automat disponibil) în loc să verifice user authentication.

## 🚀 Deploy:

```powershell
# În folder-ul proiectului:
cd C:\Users\bogda\pernador-maintain\pernador-maintain

# Copiază fișierul:
# Din package: supabase/functions/send-email/index.ts
# La: supabase/functions/send-email/index.ts

# Deploy:
npx supabase functions deploy send-email

# Wait ~30 seconds pentru deployment

# Test:
# Creează un WO cu assigned_to în aplicație
# Check email_logs pentru success!
```

## ✅ Ce Face Diferit:

**ÎNAINTE:**
```typescript
// Verifica auth header de la user
const authHeader = req.headers.get('Authorization')
// FAIL când vine de la trigger fără auth!
```

**ACUM:**
```typescript
// Folosește SERVICE_ROLE_KEY automat disponibil
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const supabase = createClient(supabaseUrl, supabaseServiceKey)
// SUCCESS! Service role are acces la tot!
```

## 📧 Email Templates Included:

✅ wo_assigned - Comandă asignată
✅ wo_urgent - Comandă urgentă  
✅ wo_completed - Comandă finalizată

## 🧪 Test După Deploy:

```sql
-- Force trigger:
UPDATE work_orders 
SET assigned_to = (SELECT id FROM profiles LIMIT 1)
WHERE id = (SELECT id FROM work_orders ORDER BY created_at DESC LIMIT 1);

-- Check logs:
SELECT * FROM email_logs ORDER BY created_at DESC LIMIT 1;

-- Trebuie să vezi:
-- status: 'sent'
-- resend_id: (un ID)
-- ✅ Email trimis!
```

## 📊 Flow Complet:

```
User asignează WO
  ↓
Trigger se activează
  ↓
Call edge function (fără auth header)
  ↓
Edge function folosește SERVICE_ROLE_KEY ✅
  ↓
Fetch data din database
  ↓
Send email via Resend
  ↓
Log în email_logs
  ↓
Success! 📧
```

**Deploy function → Test → Email magic! ✨**
